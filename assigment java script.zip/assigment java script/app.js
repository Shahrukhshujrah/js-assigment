alert(" javascript Alert \nError! Please enter a valid password.")

alert("javascript Alert \nWelcome to JS Land... \nHappy Coding!")

alert("javascript Alert \nWelcome to JS Land... ")
alert("javascript Alert \n\n\nHappy Coding! \nPrevent this page from creating additionl dialogs.")

alert("javascript Alert \nHello...Ican run JS through my web browser's console")


var myName = "asad";
alert(myName)


var message = "Hello javA";
alert(message)


var my_Name = "sHAHRUKH SHUJRAH";
var age =  "28 years old";
var course = "EWB DEV";
alert(my_Name)
alert(age)
alert(course)

alert("PIZZA" + "\n" + "PIZZ" + "\n" + "PIZ" + "\n" + "PI" + "\n" + "P" )


var email = "sharukhmyphone@gmail.com";
alert("My email address is"+email)

var book = "A smarter wat to learn JavaScript"
alert("I am trying to learn from the bk"+book)

document.write("Yah! I can write HTML content through JavaScript")

alert("“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”")

var age = "iam 25 years old";
alert(age)


alert("You have visited this site 14 times")

var birthYear = "22 sep 1995";
document.write("<br>"+birthYear)
document.write("<br>Data type of my declared variable is number")

var visitorsName = "majid";
var productTitle = "T-Shirts";
var Quantity  = 5;
document.write( "<br>" + " "  + visitorsName +  " ordered" + Quantity + " " +  productTitle + " on XYZ Clothing store")


var firstName,$name,_name;

var firstname = "chand";         //combination of alphabets
var first_name = "muhtrama";     //underscore b/w to alphabets
var firstName = "Allama";       //capital and small letter  
var FIRSTNAME = "Liaquat";      // capital letter
var firstname1 = "shoaib";      // star alphabets end number 
var _first_name = "ali";        // hyphenstart 
document.write("<br>" + " " + firstname + " " +  first_name + " " +  firstName + " " + FIRSTNAME + " " +firstname1 + " " +_first_name)

document.write("<br>Rules for naming JS variables")

document.write("<br><br> Variables names can only contain NUMBERS , $ , _  For example $my_1stVariable")

document.write("<br><br>Variables must begin with a LETTER , $ , _ For example $name , _name , name")

document.write("<br><br>Variable names are case SENSITIVE")

document.write("<br><br>Variable names should not be JS KEYWORD")


var num1 = 3;
var num2 = 5;
var num3 = num1+num2;
var num4 = num1-num2;
var num5 = num1*num2;
var num6 = num1/num2;
var num7 = num1%num2;

document.write("<br> sum of 3 and 5 is " +num3);
document.write("<br>subtract of 3 and 5 is " +num4);
document.write("<br>Multiplication of 3 and 5 is " +num5);
document.write("<br>division of 3 and 5 is " +num6);
document.write("<br>Modulus of 3 and 5 is " +num7);


var num;
//3b
document.write("<br> Value after variable declaration is :" +num)
//3c
num = 5;
document.write("<br> Initial value is :" +num)
//3d
num++;
document.write("<br>Value after increament is : " + " "  +num)

var num2 = 7;
var num3 = num2+num;
document.write("<br>Value after addition is : "+num3)
//3i
num3--;
document.write("<br>Value after decreament is : "+num3)
//3k

num3 = num/num2;
document.write("<br> The Remainder is : " +num3)



var onemovieTicket = "600";
var buy = 5;
var cost = onemovieTicket * buy;
document.write("<br>Total cost to buy 5 tickets to a movie is : "+cost + "PKR")

//Q#5
var num = 5;
for(var i=1; i<=10;++i){
    document.write("<br>" + num +" "+  "*" +" " + i +" "+ "=" + " "+ num*i)
}



function cTof(celsius){
    var cTemp = celsius;
    var cToFahr= cTemp * 9/5+32;
    var message = cTemp+'oC  is'+ " " + " " + cToFahr + 'oF.';
    document.write("<br>"+message);
}
function fToC(fehrnheit){
    var fTemp = fehrnheit;
    var fTocel = (fTemp-32) * 5/9;
    var message = fTemp+'oF is'+ " " + " " + fTocel + 'oC.';
    document.write("<br>"+message);

}

cTof(25);
fToC(70);


document.write("<br>Shopping Cart");
var item1 = 650;
var item2 = 100;
var quantity1 = 3;
var quantity2 = 7;
var shippingCharges = 100;
var result = item1*quantity1 + item2*quantity2 + shippingCharges;
document.write("<br>Total cost of your order is :"+result)



document.write("<br>Marks Sheet");
var totalMarks = 980;
var marksObtained = 804;
var per = marksObtained/totalMarks*100;
document.write("<br>percentage :" +per + "%")


document.write("<br>Currency in PKR");
var dollar = 104.80;
var riyal = 28;
document.write("<br>Total Currency in PKR",(dollar*10)+(riyal*25));



var number = 5;
var number1 = 10;
document.write("<br>"+"add"+" ",(number)+"<br>multiply by"+" ",(number1)+"<br>divide the result by :"+" ",(number1/number));


document.write("<br>Age Calculator");
var dob = new Date("1/10/1997");
var current_year  = Date.now()-dob.getTime();
var age_dt = new Date(current_year);
var year = age_dt.getUTCFullYear();
var age =  Math.abs(year - 1970);
document.write("<br> age of the date entered. "+ " "  + age + "year");


document.write("<br>The Geometrizer");
var radius = 20;
document.write("<br>The radius is :"+radius);
var circumference = Math.PI * 2*radius;
document.write("<br>The circumferece is "+circumference);
var area = Math.PI * radius*radius;
document.write("<br>The area is "+area);





var favouriteSnack = "choclatechip";
document.write("<br>FavouriteSnack :"+favouriteSnack);
var age = 15;
document.write("<br>Current age :"+age);
var maxAge = 65;
document.write("<br>Estimated Maximum age :"+maxAge);
var numPerDay = 3;
document.write("<br>Amount of snacks per day"+numPerDay);
var totalNeeded = (numPerDay*1)*(maxAge-age);
var message = 'you will need' + totalNeeded+'choclate chip to last you until the ripe old age of'+maxAge;
document.write("<br>"+message);




alert("shahrukh");
alert("shujrah");
alert("sharukhmyphone@gmail.com");
alert("+923332765304");
alert("pakistanzindabad");

var game = "Ludo";
alert(game)



var teamName ;
teamName = "sadaquat";
alert(teamName)


var bestMan  = "charlie";
bestMan = "kingdom";
console.log(bestMan)



var caseQty;
caseQty = 144;
var num =9;
var res = caseQty+num;
console.log(res)


var merchTotal = 100;
var shippingCharge = 10;
var orderTotal =merchTotal + shippingCharge;
console.log(orderTotal)


var one_num = 23;
one_num = one_num + 45;
console.log(one_num)


var productcost = 3.45;
console.log(productcost)


var nameofBand;

var quantity0 = 67;
console.log(quantity0)



var firstName = "sadaquat";
var lastName = "rafique";
document.write("<br>"+firstName + lastName)




var firstname = "chand";         //combination of alphabets
var first_name = "muhtrama";     //underscore b/w to alphabets
var firstName = "Allama";       //capital and small letter  
var FIRSTNAME = "Liaquat";      // capital letter
var firstname1 = "shoaib";      // star alphabets end number 
var _first_name = "ali";        // hyphenstart 
document.write("<br>" + " " + firstname + " " +  first_name + " " +  firstName + " " + FIRSTNAME + " " +firstname1 + " " +_first_name)




document.write("<br>The name of arithmetic operator that gives us  remainder is called :  MODULUS");
document.write("<br>The symbol of arithmetic operator that gives us  remainder is  :  %")
var x = 5;
var y = 2;
var z = x % y ;
document.write("<br>"+z)




var num = 20 % 6;
document.write("<br> "+num)


var largeNum = 1000*2000;
document.write("<br>"+largeNum)


var $num = 34;
var $num1 = 4;
var $res = $num - $num1;
document.write("<br>"+$res)


var leftOver = 10 % 3;
document.write("<br>"+leftOver)


alert(2*2);













